from flask import Flask, render_template, request, jsonify, session, redirect, url_for
import sqlite3
import hashlib
import json
import threading
import time
from datetime import datetime
from collections import defaultdict
import os

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # Change this for production

# In-memory storage for active connections (since we can't use sockets on free tier)
active_users = {}  # chatname -> last_seen timestamp
messages_queue = defaultdict(list)  # chatname -> list of messages

class ChatDatabase:
    def __init__(self, db_path='chat.db'):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize the SQLite database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Users table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                chatname TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Messages table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                from_user TEXT NOT NULL,
                to_user TEXT NOT NULL,
                message TEXT NOT NULL,
                message_type TEXT DEFAULT 'text',
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                delivered BOOLEAN DEFAULT FALSE
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def hash_password(self, password):
        """Hash password using SHA-256"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def register_user(self, username, chatname, password):
        """Register a new user"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute(
                'INSERT INTO users (username, chatname, password_hash) VALUES (?, ?, ?)',
                (username, chatname, self.hash_password(password))
            )
            conn.commit()
            conn.close()
            return True
        except sqlite3.IntegrityError:
            return False  # Username or chatname already exists
    
    def authenticate_user(self, chatname, password):
        """Authenticate user credentials"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('SELECT password_hash FROM users WHERE chatname = ?', (chatname,))
        result = cursor.fetchone()
        conn.close()
        
        if result and result[0] == self.hash_password(password):
            return True
        return False
    
    def get_user_info(self, chatname):
        """Get user information by chatname"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('SELECT username, chatname FROM users WHERE chatname = ?', (chatname,))
        result = cursor.fetchone()
        conn.close()
        
        if result:
            return {'username': result[0], 'chatname': result[1]}
        return None
    
    def save_message(self, from_user, to_user, message, msg_type='text'):
        """Save message to database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute(
            'INSERT INTO messages (from_user, to_user, message, message_type) VALUES (?, ?, ?, ?)',
            (from_user, to_user, message, msg_type)
        )
        conn.commit()
        conn.close()
    
    def get_undelivered_messages(self, chatname):
        """Get undelivered messages for a user"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute(
            'SELECT id, from_user, message, message_type, timestamp FROM messages WHERE to_user = ? AND delivered = FALSE',
            (chatname,)
        )
        messages = cursor.fetchall()
        
        # Mark messages as delivered
        if messages:
            message_ids = [msg[0] for msg in messages]
            cursor.execute(
                f'UPDATE messages SET delivered = TRUE WHERE id IN ({",".join("?" * len(message_ids))})',
                message_ids
            )
            conn.commit()
        
        conn.close()
        
        formatted_messages = []
        for msg in messages:
            formatted_messages.append({
                'from': msg[1],
                'message': msg[2],
                'type': msg[3],
                'timestamp': msg[4]
            })
        
        return formatted_messages
    
    def get_online_users(self):
        """Get list of online users"""
        online_users = []
        current_time = time.time()
        
        # Remove users who haven't been active for 5 minutes
        expired_users = [user for user, last_seen in active_users.items() 
                        if current_time - last_seen > 300]
        
        for user in expired_users:
            active_users.pop(user, None)
        
        # Get user info for active users
        for chatname in active_users.keys():
            user_info = self.get_user_info(chatname)
            if user_info:
                online_users.append(user_info)
        
        return online_users

# Initialize database
db = ChatDatabase()

# Flask Routes
@app.route('/')
def index():
    """Main chat interface"""
    if 'chatname' not in session:
        return redirect(url_for('login'))
    
    return render_template('index.html', 
                         username=session.get('username'),
                         chatname=session.get('chatname'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login/Register page"""
    if request.method == 'POST':
        action = request.form.get('action')
        username = request.form.get('username')
        chatname = request.form.get('chatname')
        password = request.form.get('password')
        
        if action == 'register':
            if db.register_user(username, chatname, password):
                session['username'] = username
                session['chatname'] = chatname
                active_users[chatname] = time.time()
                return redirect(url_for('index'))
            else:
                return render_template('login.html', error='Username or chatname already exists')
        
        elif action == 'login':
            if db.authenticate_user(chatname, password):
                session['username'] = username
                session['chatname'] = chatname
                active_users[chatname] = time.time()
                return redirect(url_for('index'))
            else:
                return render_template('login.html', error='Invalid credentials')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    """Logout user"""
    chatname = session.get('chatname')
    if chatname in active_users:
        active_users.pop(chatname)
    session.clear()
    return redirect(url_for('login'))

@app.route('/api/send_message', methods=['POST'])
def send_message():
    """API endpoint to send a message"""
    if 'chatname' not in session:
        return jsonify({'status': 'error', 'message': 'Not authenticated'})
    
    data = request.get_json()
    to_user = data.get('to')
    message = data.get('message')
    
    if not to_user or not message:
        return jsonify({'status': 'error', 'message': 'Missing parameters'})
    
    # Save message to database
    db.save_message(session['chatname'], to_user, message)
    
    # Add to real-time queue if user is online
    if to_user in active_users:
        messages_queue[to_user].append({
            'from': session['chatname'],
            'message': message,
            'type': 'text',
            'timestamp': datetime.now().isoformat()
        })
    
    return jsonify({'status': 'success'})

@app.route('/api/get_messages')
def get_messages():
    """API endpoint to get new messages"""
    if 'chatname' not in session:
        return jsonify({'status': 'error', 'message': 'Not authenticated'})
    
    chatname = session['chatname']
    
    # Update user activity
    active_users[chatname] = time.time()
    
    # Check both database and real-time queue
    messages = []
    
    # Get undelivered messages from database
    db_messages = db.get_undelivered_messages(chatname)
    messages.extend(db_messages)
    
    # Get messages from real-time queue
    if chatname in messages_queue and messages_queue[chatname]:
        messages.extend(messages_queue[chatname])
        messages_queue[chatname] = []  # Clear the queue
    
    return jsonify({'status': 'success', 'messages': messages})

@app.route('/api/online_users')
def get_online_users():
    """API endpoint to get online users"""
    if 'chatname' not in session:
        return jsonify({'status': 'error', 'message': 'Not authenticated'})
    
    online_users = db.get_online_users()
    return jsonify({'status': 'success', 'users': online_users})

@app.route('/api/user_info')
def get_user_info():
    """API endpoint to get current user info"""
    if 'chatname' not in session:
        return jsonify({'status': 'error', 'message': 'Not authenticated'})
    
    user_info = db.get_user_info(session['chatname'])
    return jsonify({'status': 'success', 'user': user_info})

@app.route('/status')
def status():
    """Server status page"""
    stats = {
        'online_users': len(active_users),
        'total_users': len(db.get_online_users()),  # This will query all users
        'queue_size': sum(len(q) for q in messages_queue.values())
    }
    return render_template('status.html', stats=stats)

# Background thread to clean up expired users
def cleanup_expired_users():
    """Background task to clean up expired user sessions"""
    while True:
        current_time = time.time()
        expired_users = [user for user, last_seen in active_users.items() 
                        if current_time - last_seen > 300]  # 5 minutes
        
        for user in expired_users:
            active_users.pop(user, None)
            print(f"Cleaned up expired user: {user}")
        
        time.sleep(60)  # Run every minute

# Start cleanup thread
cleanup_thread = threading.Thread(target=cleanup_expired_users, daemon=True)
cleanup_thread.start()

if __name__ == '__main__':
    app.run(debug=True)
